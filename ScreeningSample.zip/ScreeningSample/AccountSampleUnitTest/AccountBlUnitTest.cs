﻿using System;
using AccountSample;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace AccountSampleUnitTest
{
    [TestClass]
    public class AccountBlUnitTest
    {
        [TestMethod]
        public void GetInvestmentAccountsTest()
        {
            AccountBl handler = new AccountBl(new FakeDataStore());
            var accounts = handler.GetInvestmentAccounts(25, AccountType.Investment);
            var expectedAccounts = FakeAccounts.GetList();
            CollectionAssert.AreEqual(expectedAccounts, accounts);
        }
    }
}
