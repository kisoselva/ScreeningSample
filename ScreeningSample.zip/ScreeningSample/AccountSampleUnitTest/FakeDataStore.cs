﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccountSample
{
    public class FakeDataStore : IDataStore
    {
        public List<Account> LoadAccounts(int clientId)
        {
            return new List<Account>() { new Account() { AccountNumber = "25", AccountOwner = 25, AccountType = AccountType.Investment } };
        }
    }
}
