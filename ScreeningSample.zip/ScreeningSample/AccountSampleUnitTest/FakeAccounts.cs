﻿using AccountSample;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccountSampleUnitTest
{
    public static class FakeAccounts
    {
        public static List<Account> GetList()
        {
            return new List<Account>() { new Account() { AccountNumber = "25", AccountOwner = 25, AccountType = AccountType.Investment } };
        }
    }
}
