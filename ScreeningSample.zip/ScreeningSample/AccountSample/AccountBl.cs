﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace AccountSample
{
    public class AccountBl
    {
        private readonly IDataStore _dataStore;

        public AccountBl(IDataStore dataStore)
        {
            _dataStore = dataStore;
        }

        public List<Account> GetInvestmentAccounts(int clientId, AccountType accountType)
        {
            if (accountType == AccountType.Investment)
            {
                var accounts = _dataStore.LoadAccounts(clientId);
                return accounts.Where(a => a.AccountType == AccountType.Investment).ToList();
            }
            throw new Exception("Invalid account type provided");
        }
    }
}