﻿namespace AccountSample
{
    public enum AccountType
    {
        Checking,
        Savings,
        Investment,
        Trading,
    }
}