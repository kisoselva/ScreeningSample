﻿using System.Collections.Generic;

namespace AccountSample
{
    public interface IDataStore
    {
        List<Account> LoadAccounts(int clientId);
    }
}