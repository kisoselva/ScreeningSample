﻿using System;

namespace AccountSample
{
    public class Account
    {
        //Mandatory
        public string AccountNumber { get; set; }
        //Mandatory
        public AccountType AccountType { get; set; }
        //Mandatory
        public int AccountOwner { get; set; }

        public override bool Equals(Object obj)
        {
            if (obj == null)
                return false;

            Account other = obj as Account;
            if ((Object)other == null)
                return false;

            // here you need to compare two objects
            // below is just example implementation

            return this.AccountNumber == other.AccountNumber
                && this.AccountType == other.AccountType
                && this.AccountOwner == other.AccountOwner;
        }
    }
}